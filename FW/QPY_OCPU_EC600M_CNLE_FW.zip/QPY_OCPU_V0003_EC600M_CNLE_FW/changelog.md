## Release History
**[QPY_OCPU_V0003_EC600M_CNLE_FW] 2024-03-19**
* Support function list
1. (U)SIM
2. Data Call
3. FILE
4. aLiYun
5. HTTP
6. HTTPS
7. MQTT
8. NITZ
9. NTP
10. PING
11. SSL
12. TCP/UDP
13. Camera
14. ADC
15. Alarm
16. Audio Play
17. Audio Playback
18. Audio Record
19. Device Info
20. EINT
21. Ethernet
22. FOTA
23. GPIO
24. IIC
25. Low Power
26. MiniFOTA
27. Modem
28. PWM
29. SIM Detection
30. SPI
31. TTS
32. Timer
33. UART
34. USB
35. WIFI Scan
36. Encryption and Decryption
37. SM
38. Network






